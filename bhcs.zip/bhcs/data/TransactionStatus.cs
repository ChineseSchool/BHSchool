﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace data
{
    public enum TransactionStatus
    {
        Confirmed = 0,
        Cancelled = 1
    }
}
