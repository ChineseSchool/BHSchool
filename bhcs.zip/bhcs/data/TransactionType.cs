﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace data
{
    public enum TransactionType
    {
        Registration = 0,
        Fee = 1
    }
}
